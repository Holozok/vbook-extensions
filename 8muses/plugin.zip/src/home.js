function execute() {
    return Response.success([
    //    {title: "Home", input: "?page={0}", script: "gen.js"},
        {title: "Fakku Comics", input: "album/Fakku-Comics?page={0}", script: "gen.js"},
        {title: "Hentai and Manga English", input: "album/Hentai-and-Manga-English?page={0}", script: "gen.js"},
        {title: "MilfToon Comics", input: "album/MilfToon-Comics?page={0}", script: "gen.js"},
        {title: "JAB Comics", input: "album/JAB-Comics?page={0}", script: "gen.js"},
        {title: "Various Authors", input: "album/Various-Authors?page={0}", script: "gen.js"},
        {title: "Melkormancin com Comics", input: "album/Melkormancin_com-Comics?page={0}", script: "gen.js"},
        {title: "PalComix Comics", input: "album/PalComix-Comics?page={0}", script: "gen.js"},
        {title: "Fred Perry Comics", input: "album/Fred-Perry-Comics?page={0}", script: "gen.js"},
        {title: "DreamTales Comics", input: "album/DreamTales-Comics?page={0}", script: "gen.js"},
        {title: "IncestIncestIncest com Comics", input: "album/IncestIncestIncest_com-Comics?page={0}", script: "gen.js"},
        {title: "Witchking00 Comics", input: "album/Witchking00-Comics?page={0}", script: "gen.js"},
        {title: "Nihaotomita Comics", input: "album/Nihaotomita-Comics?page={0}", script: "gen.js"},
    ]);
}