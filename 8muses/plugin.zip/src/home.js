function execute() {
    return Response.success([
        {title: "Fakku Comics", input: "album/Fakku-Comics/{0}", script: "gen.js"},
        {title: "Hentai and Manga English", input: "album/Hentai-and-Manga-English/{0}", script: "gen.js"},
        {title: "MilfToon Comics", input: "album/MilfToon-Comics/{0}", script: "gen.js"},
        {title: "JAB Comics", input: "album/JAB-Comics/{0}", script: "gen.js"},
        {title: "Various Authors", input: "album/Various-Authors/{0}", script: "gen.js"},
        {title: "Melkormancin com Comics", input: "album/Melkormancin_com-Comics/{0}", script: "gen.js"},
        {title: "PalComix Comics", input: "album/PalComix-Comics/{0}", script: "gen.js"},
        {title: "Fred Perry Comics", input: "album/Fred-Perry-Comics/{0}", script: "gen.js"},
        {title: "DreamTales Comics", input: "album/DreamTales-Comics/{0}", script: "gen.js"},
        {title: "IncestIncestIncest com Comics", input: "album/IncestIncestIncest_com-Comics/{0}", script: "gen.js"},
        {title: "Witchking00 Comics", input: "album/Witchking00-Comics/{0}", script: "gen.js"},
        {title: "Nihaotomita Comics", input: "album/Nihaotomita-Comics/{0}", script: "gen.js"},
    ]);
}